#pragma once

void nice_service(void *, int);
